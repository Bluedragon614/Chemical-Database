package databaserunner;

public class DatabaseRunner {
    public static void main(String[] args) {  
        //Save Cancel error *fixed
        //Max limit on atomic #
        //Exiting out of Simulate reaction allows you to not name compound
            //Fix: prompt on exit, remove on exit
        //COMMENTS
        new DatabaseGUI();
    }
}